The assignment went well. 
I am able to solve in a short time by using the same method that was taught in class. 