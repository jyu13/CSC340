First part of assignment is Linkedlist
Second part of assignment is DoubleLinkedlist
They are store into two separate files called LinkedList and DoubleLinkedList
Each file contains three files, header file, implemention file, and mail file(test file)

All the files complie and run by using dev-c++

LinkedList contained double as data, and DoubleLinkedlist conatined int as data.

I connnected three files into a console output project in order for dev-c++ to complie and run
without puting into a project, dev-c++ will consider it is a window output file and would give an error.