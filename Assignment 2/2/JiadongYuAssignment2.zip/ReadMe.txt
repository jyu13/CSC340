all three parts complie and run in dev-c++

1. maxTime.cpp slove for question part one 
2. fileMerge.cpp slove for question part two
3. ranAccess.cpp slove for question part three