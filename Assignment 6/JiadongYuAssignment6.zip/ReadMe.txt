tree.h, tree.cpp, and tree_main.cpp added to Dev-c++ console project

all three files complie and run by Dev-c++

it passed all the test that was required 