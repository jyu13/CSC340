Both reformateDate and stringFreq can compile and run by using Dev-c++

First program reformateDate limit any invaild input and invaild date. Program will ask for another input until the user press q to exit or enter a vaild date.
I wrote a function that will convert string with integer represetions to integer.

Second program stringFreq will count how many words appeared in a paragraph.