recursion.cpp complie and run under dev-c++

isPalindrome takes a string and check if it is palindrome, return boolean 0 or 1

digitSum accepts positive integer and return its sum

waysToClimb accepts positive integer, and it is a fibonacci series, so it will be calculate like fibonacci number.